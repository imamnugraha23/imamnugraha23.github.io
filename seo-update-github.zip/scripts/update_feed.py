import json, re, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

SOURCES=[
("Search Engine Journal","https://www.searchenginejournal.com/feed/",["SEO","AI Search","Ads"]),
("Google Search Central","https://developers.google.com/search/blog/feed.xml",["Google","SEO","Technical"]),
("Search Engine Roundtable","https://www.seroundtable.com/index.xml",["Google","SEO","Technical"]),
("Search Engine Land","https://searchengineland.com/feed",["SEO","Google","AI Search","Ads"])
]

def clean(s):
    s=re.sub(r"<[^>]+>"," ",s or "")
    return re.sub(r"\s+"," ",s).strip()

def date_value(s):
    if not s:return datetime.now(timezone.utc).isoformat()
    try:return parsedate_to_datetime(s).astimezone(timezone.utc).isoformat()
    except:
        try:return datetime.fromisoformat(s.replace("Z","+00:00")).isoformat()
        except:return datetime.now(timezone.utc).isoformat()

def text(node, names):
    for child in list(node):
        tag=child.tag.split("}")[-1].lower()
        if tag in names:
            if tag=="link" and child.attrib.get("href"): return child.attrib["href"]
            return "".join(child.itertext())
    return ""

all_items=[]; states=[]
for name,url,tags in SOURCES:
    try:
        req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 SEO-Updates-GitHub/1.0","Accept":"application/rss+xml, application/xml, text/xml, */*"})
        with urllib.request.urlopen(req,timeout=20) as r: raw=r.read()
        root=ET.fromstring(raw)
        nodes=list(root.findall(".//item")) or list(root.findall(".//{*}entry"))
        count=0
        for n in nodes:
            title=clean(text(n,{"title"})); link=text(n,{"link"}).strip()
            if not link:
                for x in n:
                    if x.tag.split("}")[-1].lower()=="link" and x.attrib.get("href"): link=x.attrib["href"];break
            dt=text(n,{"pubdate","published","updated","date","dc:date"})
            desc=clean(text(n,{"description","summary","encoded","content"}))
            if title and link:
                all_items.append({"title":title,"link":link,"date":date_value(dt),"description":desc,"source":name,"tags":tags});count+=1
        states.append({"name":name,"ok":True,"count":count})
    except Exception as e:
        states.append({"name":name,"ok":False,"count":0,"error":str(e)})

unique={}
for x in all_items: unique.setdefault(x["link"],x)
items=sorted(unique.values(),key=lambda x:x["date"],reverse=True)[:200]
data={"updatedAt":datetime.now(timezone.utc).isoformat(),"items":items,"sources":states}
Path("data.json").write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
print("Updated",len(items),"articles")
for s in states: print(s["name"],s["count"],"OK" if s["ok"] else "FAILED")
